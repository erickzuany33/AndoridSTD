package com.example.examenu1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtPuntos, txtCali, txtResu;
    SeekBar sbarPuntos, sbarCali;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtPuntos = findViewById(R.id.txtPuntos);
        txtCali = findViewById(R.id.txtCali);
        txtResu = findViewById(R.id.txtResu);
        sbarPuntos = findViewById(R.id.sbarPuntos);
        sbarCali = findViewById(R.id.sbarCali);

        sbarPuntos.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtPuntos.setText(" " + i);
                if (sbarPuntos.getProgress() <= sbarCali.getProgress()){
                    txtResu.setText("APROBADO");
                }
                else{
                    txtResu.setText("REPROBADO");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sbarCali.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtCali.setText(" " + i);
                if (sbarPuntos.getProgress() <= sbarCali.getProgress()){
                    txtResu.setText("APROBADO");
                }
                else{
                    txtResu.setText("REPROBADO");
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



    }


}
